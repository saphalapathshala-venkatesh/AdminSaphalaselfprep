"use client";
export const dynamic = "force-dynamic";

import { useState, useEffect, useCallback } from "react";
import Link from "next/link";
import { BRAND } from "@/lib/adminStyles";

interface DashboardData {
  kpis: { totalUsers: number; grossRevenuePaise: number; netRevenuePaise: number; paidUsers: number; freeUsers: number };
  charts: {
    attemptsByDay: { date: string; count: number }[];
    activeUsersByDay: { date: string; count: number }[];
    xpByDay: { date: string; points: number }[];
    revenueByDay: { date: string; grossPaise: number; netPaise: number }[];
  };
  tables: {
    topXpEarners: { userId: string; name: string | null; email: string | null; totalXp: number }[];
    mostAttemptedTests: { testId: string; title: string; attempts: number }[];
    recentlyPublishedContent: { type: string; id: string; title: string; publishedAt: string | null }[];
  };
}

const PRESETS: Record<string, () => [string, string]> = {
  "Today": () => { const d = new Date().toISOString().slice(0, 10); return [d, d]; },
  "7 Days": () => { const e = new Date(); const s = new Date(e.getTime() - 6 * 86400000); return [s.toISOString().slice(0, 10), e.toISOString().slice(0, 10)]; },
  "30 Days": () => { const e = new Date(); const s = new Date(e.getTime() - 29 * 86400000); return [s.toISOString().slice(0, 10), e.toISOString().slice(0, 10)]; },
  "90 Days": () => { const e = new Date(); const s = new Date(e.getTime() - 89 * 86400000); return [s.toISOString().slice(0, 10), e.toISOString().slice(0, 10)]; },
  "1 Year": () => { const e = new Date(); const s = new Date(e.getTime() - 364 * 86400000); return [s.toISOString().slice(0, 10), e.toISOString().slice(0, 10)]; },
};

const STREAMS = [
  { value: "all", label: "All Streams" },
  { value: "TESTHUB", label: "TestHub" },
  { value: "SELFPREP_HTML", label: "SelfPrep HTML" },
  { value: "FLASHCARDS", label: "Flashcards" },
  { value: "PDF_ACCESS", label: "PDF Access" },
  { value: "SMART_PRACTICE", label: "Smart Practice" },
  { value: "AI_ADDON", label: "AI Add-on" },
];

const QUICK_ACTIONS = [
  { label: "Create E-Book", href: "/admin/content-library" },
  { label: "Upload PDF", href: "/admin/content-library" },
  { label: "Create Flashcards", href: "/admin/flashcards" },
  { label: "Create Test Series", href: "/admin/test-series" },
];

interface InfringementStats {
  todayCount: number;
  weekCount: number;
  warning1: number;
  warning2: number;
  blocked: number;
  recent: { id: string; eventType: string; contentType: string; createdAt: string; user: { name: string | null; email: string | null } }[];
}

export default function DashboardPage() {
  const defaultRange = PRESETS["30 Days"]();
  const [start, setStart] = useState(defaultRange[0]);
  const [end, setEnd] = useState(defaultRange[1]);
  const [learnerFilter, setLearnerFilter] = useState("all");
  const [stream, setStream] = useState("all");
  const [data, setData] = useState<DashboardData | null>(null);
  const [loading, setLoading] = useState(true);
  const [infStats, setInfStats] = useState<InfringementStats | null>(null);

  const fetchDashboard = useCallback(async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams({ start, end, learnerFilter, stream });
      const res = await fetch(`/api/analytics/dashboard?${params}`);
      const json = await res.json();
      setData(json.data || null);
    } catch { setData(null); }
    setLoading(false);
  }, [start, end, learnerFilter, stream]);

  useEffect(() => { fetchDashboard(); }, [fetchDashboard]);

  useEffect(() => {
    fetch("/api/admin/infringement/stats")
      .then(r => r.json())
      .then(d => setInfStats(d))
      .catch(() => {});
  }, []);

  const applyPreset = (name: string) => {
    const [s, e] = PRESETS[name]();
    setStart(s);
    setEnd(e);
  };

  const inputStyle: React.CSSProperties = { padding: "0.375rem 0.5rem", border: "1px solid #d1d5db", borderRadius: "0.375rem", fontSize: "0.8rem" };
  const thStyle: React.CSSProperties = { padding: "0.5rem 0.75rem", textAlign: "left", borderBottom: "2px solid #e5e7eb", fontSize: "0.7rem", fontWeight: 600, color: "#6b7280", textTransform: "uppercase" };
  const tdStyle: React.CSSProperties = { padding: "0.5rem 0.75rem", borderBottom: "1px solid #f3f4f6", fontSize: "0.8rem" };
  const card: React.CSSProperties = { background: "#fff", borderRadius: "0.5rem", padding: "1rem", boxShadow: "0 1px 4px rgba(0,0,0,0.07)" };

  const chartTitle: React.CSSProperties = { fontSize: "0.8rem", fontWeight: 600, marginBottom: "0.75rem", color: "#374151", textTransform: "uppercase", letterSpacing: "0.04em" };

  const skeletonLine = ({ w, h, mb }: { w: string; h: string; mb?: string }): React.CSSProperties => ({
    width: w, height: h, borderRadius: "4px",
    background: "linear-gradient(90deg, #f3f4f6 25%, #e5e7eb 50%, #f3f4f6 75%)",
    backgroundSize: "200% 100%",
    animation: "shimmer 1.4s infinite",
    marginBottom: mb || 0,
    flexShrink: 0,
  });

  const maxVal = (arr: number[]) => Math.max(...arr, 1);

  const MiniBar = ({ items, valKey, labelKey, color }: { items: any[]; valKey: string; labelKey: string; color: string }) => {
    if (items.length === 0) return <p style={{ color: "#999", fontSize: "0.8rem" }}>No data for this period.</p>;
    const mv = maxVal(items.map(i => i[valKey]));
    return (
      <div style={{ display: "flex", flexDirection: "column", gap: "2px" }}>
        {items.slice(-14).map((item, idx) => (
          <div key={idx} style={{ display: "flex", alignItems: "center", gap: "0.5rem", fontSize: "0.7rem" }}>
            <span style={{ width: "70px", flexShrink: 0, color: "#6b7280" }}>{item[labelKey]?.slice(5) || ""}</span>
            <div style={{ flex: 1, background: "#f3f4f6", borderRadius: "2px", height: "14px" }}>
              <div style={{ width: `${(item[valKey] / mv) * 100}%`, background: color, height: "100%", borderRadius: "2px", minWidth: item[valKey] > 0 ? "2px" : "0" }} />
            </div>
            <span style={{ width: "50px", textAlign: "right", fontWeight: 500 }}>{item[valKey]}</span>
          </div>
        ))}
      </div>
    );
  };

  const KPIs = [
    { label: "Total Users",    value: (d: DashboardData) => d.kpis.totalUsers.toLocaleString(),                                                         color: BRAND.blue,       icon: "👥" },
    { label: "Paid Users",     value: (d: DashboardData) => d.kpis.paidUsers.toLocaleString(),                                                          color: BRAND.green,      icon: "✅" },
    { label: "Free Users",     value: (d: DashboardData) => d.kpis.freeUsers.toLocaleString(),                                                          color: BRAND.gray,       icon: "🎓" },
    { label: "Gross Revenue",  value: (d: DashboardData) => `₹${(d.kpis.grossRevenuePaise / 100).toLocaleString(undefined, { minimumFractionDigits: 2 })}`, color: BRAND.purple, icon: "💰" },
    { label: "Net Revenue",    value: (d: DashboardData) => `₹${(d.kpis.netRevenuePaise / 100).toLocaleString(undefined, { minimumFractionDigits: 2 })}`,   color: BRAND.cyan,   icon: "📈" },
  ];

  return (
    <div>
      <style>{`
        @keyframes shimmer {
          0% { background-position: 200% 0; }
          100% { background-position: -200% 0; }
        }
      `}</style>
      {/* ── Branded Hero ── */}
      <div style={{
        background: `linear-gradient(135deg, ${BRAND.purpleDeep} 0%, ${BRAND.purpleDark} 45%, ${BRAND.purple} 100%)`,
        borderRadius: "0.75rem",
        padding: "1.25rem 2rem",
        marginBottom: "1.75rem",
        display: "flex",
        alignItems: "center",
        gap: "1.5rem",
        boxShadow: "0 6px 24px rgba(109,40,217,0.22)",
      }}>
        {/* Logo */}
        <div style={{
          width: "80px", height: "80px",
          background: "#fff",
          borderRadius: "14px",
          display: "flex", alignItems: "center", justifyContent: "center",
          flexShrink: 0,
          boxShadow: "0 2px 12px rgba(0,0,0,0.18)",
          overflow: "hidden",
          padding: "4px",
        }}>
          <img
            src="/saphala-logo.png"
            alt="Saphala Logo"
            style={{ width: "100%", height: "100%", objectFit: "contain" }}
          />
        </div>
        <div>
          <div style={{ fontSize: "1.4rem", fontWeight: 700, color: "#fff", letterSpacing: "-0.02em", lineHeight: 1.2 }}>
            Saphala Pathshala Admin
          </div>
          <div style={{ fontSize: "0.875rem", color: "rgba(255,255,255,0.75)", marginTop: "0.35rem", fontStyle: "italic" }}>
            Your Success is our Focus
          </div>
        </div>
        <div style={{ marginLeft: "auto", textAlign: "right" }}>
          <div style={{ fontSize: "0.65rem", color: "rgba(255,255,255,0.55)", textTransform: "uppercase", letterSpacing: "0.08em", fontWeight: 600 }}>
            Admin Console
          </div>
          <div style={{ fontSize: "0.7rem", color: "rgba(255,255,255,0.4)", marginTop: "0.25rem" }}>
            Saphala Self Prep
          </div>
        </div>
      </div>

      {/* ── Filter Bar ── */}
      <div style={{ display: "flex", gap: "0.5rem", marginBottom: "1.5rem", flexWrap: "wrap", alignItems: "center", padding: "0.75rem", background: "#f9fafb", borderRadius: "0.5rem", border: "1px solid #e5e7eb" }}>
        {Object.keys(PRESETS).map(name => (
          <button key={name} onClick={() => applyPreset(name)} style={{ padding: "0.25rem 0.625rem", border: "1px solid #d1d5db", borderRadius: "0.375rem", background: "#fff", cursor: "pointer", fontSize: "0.75rem", color: "#374151" }}>{name}</button>
        ))}
        <input type="date" value={start} onChange={e => setStart(e.target.value)} style={inputStyle} />
        <span style={{ fontSize: "0.8rem", color: "#6b7280" }}>to</span>
        <input type="date" value={end} onChange={e => setEnd(e.target.value)} style={inputStyle} />
        <select value={learnerFilter} onChange={e => setLearnerFilter(e.target.value)} style={inputStyle}>
          <option value="all">All Learners</option>
          <option value="paid">Paid</option>
          <option value="free">Free</option>
        </select>
        <select value={stream} onChange={e => setStream(e.target.value)} style={inputStyle}>
          {STREAMS.map(s => <option key={s.value} value={s.value}>{s.label}</option>)}
        </select>
      </div>

      {/* ── KPI Cards — render skeleton immediately, swap in real data when ready ── */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(170px, 1fr))", gap: "1rem", marginBottom: "1.75rem" }}>
        {loading ? (
          Array.from({ length: 5 }).map((_, i) => (
            <div key={i} style={{ background: "#fff", borderRadius: "0.5rem", padding: "1.125rem 1.25rem", boxShadow: "0 1px 4px rgba(0,0,0,0.07)", borderLeft: "4px solid #e5e7eb" }}>
              <div style={skeletonLine({ w: "55%", h: "10px", mb: "0.6rem" })} />
              <div style={skeletonLine({ w: "70%", h: "22px" })} />
            </div>
          ))
        ) : !data ? (
          <div style={{ gridColumn: "1/-1" }}>
            <p style={{ color: "#999" }}>Failed to load dashboard data.</p>
          </div>
        ) : (
          KPIs.map(kpi => (
            <div key={kpi.label} style={{ background: "#fff", borderRadius: "0.5rem", padding: "1.125rem 1.25rem", boxShadow: "0 1px 4px rgba(0,0,0,0.07)", borderLeft: `4px solid ${kpi.color}`, display: "flex", flexDirection: "column", gap: "0.375rem" }}>
              <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
                <span style={{ fontSize: "0.7rem", color: "#6b7280", fontWeight: 600, textTransform: "uppercase", letterSpacing: "0.04em" }}>{kpi.label}</span>
                <span style={{ fontSize: "1rem" }}>{kpi.icon}</span>
              </div>
              <div style={{ fontSize: "1.375rem", fontWeight: 700, color: "#111", letterSpacing: "-0.02em" }}>{kpi.value(data)}</div>
            </div>
          ))
        )}
      </div>

      {/* ── Charts ── */}
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "1rem", marginBottom: "1.75rem" }}>
        {loading ? (
          Array.from({ length: 4 }).map((_, i) => (
            <div key={i} style={card}>
              <div style={skeletonLine({ w: "45%", h: "10px", mb: "0.75rem" })} />
              {Array.from({ length: 7 }).map((__, j) => (
                <div key={j} style={{ display: "flex", alignItems: "center", gap: "0.5rem", marginBottom: "4px" }}>
                  <div style={skeletonLine({ w: "60px", h: "10px" })} />
                  <div style={{ ...skeletonLine({ w: `${40 + Math.random() * 50}%`, h: "12px" }), flex: 1 }} />
                </div>
              ))}
            </div>
          ))
        ) : data ? (
          <>
            <div style={card}>
              <h3 style={chartTitle}>Attempts / Day</h3>
              <MiniBar items={data.charts.attemptsByDay} valKey="count" labelKey="date" color={BRAND.blue} />
            </div>
            <div style={card}>
              <h3 style={chartTitle}>Active Users / Day</h3>
              <MiniBar items={data.charts.activeUsersByDay} valKey="count" labelKey="date" color={BRAND.green} />
            </div>
            <div style={card}>
              <h3 style={chartTitle}>XP / Day</h3>
              <MiniBar items={data.charts.xpByDay} valKey="points" labelKey="date" color={BRAND.purple} />
            </div>
            <div style={card}>
              <h3 style={chartTitle}>Revenue / Day (Gross)</h3>
              <MiniBar items={data.charts.revenueByDay} valKey="grossPaise" labelKey="date" color={BRAND.cyan} />
            </div>
          </>
        ) : null}
      </div>

      {/* ── Tables ── */}
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "1rem", marginBottom: "1.75rem" }}>
        {loading ? (
          Array.from({ length: 2 }).map((_, i) => (
            <div key={i} style={card}>
              <div style={skeletonLine({ w: "50%", h: "10px", mb: "0.75rem" })} />
              {Array.from({ length: 5 }).map((__, j) => (
                <div key={j} style={{ display: "flex", gap: "0.5rem", marginBottom: "8px" }}>
                  <div style={skeletonLine({ w: "20px", h: "12px" })} />
                  <div style={{ ...skeletonLine({ w: "60%", h: "12px" }), flex: 1 }} />
                  <div style={skeletonLine({ w: "40px", h: "12px" })} />
                </div>
              ))}
            </div>
          ))
        ) : data ? (
          <>
            <div style={card}>
              <h3 style={chartTitle}>Top XP Earners</h3>
              {data.tables.topXpEarners.length === 0 ? <p style={{ fontSize: "0.8rem", color: "#999" }}>No data.</p> : (
                <table style={{ width: "100%", borderCollapse: "collapse" }}>
                  <thead><tr><th style={thStyle}>#</th><th style={thStyle}>User</th><th style={thStyle}>XP</th></tr></thead>
                  <tbody>
                    {data.tables.topXpEarners.map((u, i) => (
                      <tr key={u.userId}>
                        <td style={tdStyle}>{i + 1}</td>
                        <td style={tdStyle}>{u.name || u.email || u.userId}</td>
                        <td style={{ ...tdStyle, fontWeight: 600, color: BRAND.purple }}>{u.totalXp}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}
            </div>
            <div style={card}>
              <h3 style={chartTitle}>Most Attempted Tests</h3>
              {data.tables.mostAttemptedTests.length === 0 ? <p style={{ fontSize: "0.8rem", color: "#999" }}>No data.</p> : (
                <table style={{ width: "100%", borderCollapse: "collapse" }}>
                  <thead><tr><th style={thStyle}>#</th><th style={thStyle}>Test</th><th style={thStyle}>Attempts</th></tr></thead>
                  <tbody>
                    {data.tables.mostAttemptedTests.map((t, i) => (
                      <tr key={t.testId}>
                        <td style={tdStyle}>{i + 1}</td>
                        <td style={tdStyle}>{t.title}</td>
                        <td style={{ ...tdStyle, fontWeight: 600 }}>{t.attempts}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}
            </div>
          </>
        ) : null}
      </div>

      {/* ── Recently Published ── */}
      {loading ? (
        <div style={{ ...card, marginBottom: "1.75rem" }}>
          <div style={skeletonLine({ w: "40%", h: "10px", mb: "0.75rem" })} />
          {Array.from({ length: 4 }).map((_, i) => (
            <div key={i} style={{ display: "flex", gap: "0.75rem", marginBottom: "8px" }}>
              <div style={skeletonLine({ w: "40px", h: "12px" })} />
              <div style={{ ...skeletonLine({ w: "50%", h: "12px" }), flex: 1 }} />
              <div style={skeletonLine({ w: "70px", h: "12px" })} />
            </div>
          ))}
        </div>
      ) : data ? (
        <div style={{ ...card, marginBottom: "1.75rem" }}>
          <h3 style={chartTitle}>Recently Published Content</h3>
          {data.tables.recentlyPublishedContent.length === 0 ? <p style={{ fontSize: "0.8rem", color: "#999" }}>No published content.</p> : (
            <table style={{ width: "100%", borderCollapse: "collapse" }}>
              <thead><tr><th style={thStyle}>Type</th><th style={thStyle}>Title</th><th style={thStyle}>Published</th></tr></thead>
              <tbody>
                {data.tables.recentlyPublishedContent.map(c => (
                  <tr key={c.id}>
                    <td style={tdStyle}>
                      <span style={{ padding: "0.125rem 0.375rem", borderRadius: "0.25rem", fontSize: "0.65rem", fontWeight: 500, background: c.type === "HTML" ? "#dbeafe" : "#ede9fe", color: c.type === "HTML" ? "#1e40af" : BRAND.purpleText }}>{c.type}</span>
                    </td>
                    <td style={tdStyle}>{c.title}</td>
                    <td style={{ ...tdStyle, fontSize: "0.75rem", color: "#6b7280" }}>{c.publishedAt ? new Date(c.publishedAt).toLocaleDateString() : "—"}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      ) : null}

      {/* ── Infringement Activity Card ── */}
      {infStats && (
        <div style={{ ...card, marginBottom: "1.75rem", borderLeft: "4px solid #ef4444" }}>
          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: "1rem" }}>
            <h3 style={{ ...chartTitle, margin: 0, color: "#dc2626" }}>🔒 Content Infringement Activity</h3>
            <Link href="/admin/users/infringement" style={{ fontSize: "0.75rem", color: BRAND.purple, textDecoration: "none", fontWeight: 600 }}>View All →</Link>
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(120px, 1fr))", gap: "0.75rem", marginBottom: "1rem" }}>
            {[
              { label: "Today", value: infStats.todayCount, color: "#6b7280" },
              { label: "This Week", value: infStats.weekCount, color: "#6b7280" },
              { label: "1st Warning", value: infStats.warning1, color: "#d97706" },
              { label: "2nd Warning", value: infStats.warning2, color: "#ea580c" },
              { label: "Auto-Blocked", value: infStats.blocked, color: "#dc2626" },
            ].map(stat => (
              <div key={stat.label} style={{ background: "#fafafa", borderRadius: 8, padding: "0.625rem 0.75rem", textAlign: "center", border: "1px solid #f3f4f6" }}>
                <div style={{ fontSize: "1.25rem", fontWeight: 800, color: stat.color }}>{stat.value}</div>
                <div style={{ fontSize: "0.65rem", color: "#9ca3af", fontWeight: 600, textTransform: "uppercase", letterSpacing: "0.04em" }}>{stat.label}</div>
              </div>
            ))}
          </div>
          {infStats.recent.length > 0 && (
            <div>
              <div style={{ fontSize: "0.65rem", fontWeight: 700, color: "#9ca3af", textTransform: "uppercase", letterSpacing: "0.05em", marginBottom: "0.5rem" }}>Recent Events</div>
              {infStats.recent.map(ev => (
                <div key={ev.id} style={{ display: "flex", alignItems: "center", gap: "0.75rem", padding: "0.35rem 0", borderBottom: "1px solid #f9fafb", fontSize: "0.78rem" }}>
                  <span style={{ color: "#9ca3af", fontSize: "0.7rem", flexShrink: 0 }}>{new Date(ev.createdAt).toLocaleDateString()}</span>
                  <span style={{ fontWeight: 600, color: "#374151", flex: 1, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{ev.user.name || ev.user.email || "Unknown"}</span>
                  <span style={{ fontSize: "0.7rem", background: "#fee2e2", color: "#991b1b", borderRadius: 4, padding: "1px 6px", flexShrink: 0 }}>{ev.eventType.replace(/_/g, " ")}</span>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* ── Quick Actions — always visible, no data dependency ── */}
      <div>
        <div style={{ fontSize: "0.7rem", fontWeight: 600, color: "#6b7280", textTransform: "uppercase", letterSpacing: "0.06em", marginBottom: "0.625rem" }}>Quick Actions</div>
        <div style={{ display: "flex", gap: "0.75rem", flexWrap: "wrap" }}>
          {QUICK_ACTIONS.map(a => (
            <Link key={a.label} href={a.href} style={{
              padding: "0.5rem 1.125rem",
              background: BRAND.purple,
              color: "#fff",
              borderRadius: "0.375rem",
              textDecoration: "none",
              fontSize: "0.8rem",
              fontWeight: 500,
              boxShadow: "0 1px 3px rgba(124,58,237,0.3)",
            }}>
              {a.label}
            </Link>
          ))}
        </div>
      </div>
    </div>
  );
}
